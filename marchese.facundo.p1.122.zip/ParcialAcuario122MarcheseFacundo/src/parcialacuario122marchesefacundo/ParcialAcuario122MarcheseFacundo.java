package parcialacuario122marchesefacundo;

public class ParcialAcuario122MarcheseFacundo {

    public static void main(String[] args) {
        Acuario acuario = new Acuario();

        try {
            acuario.agregarAnimal(new Pez("Nemo", 0.5, TipoAgua.DULCE));
            acuario.agregarAnimal(new MamiferoMarino("Delfin", 150.0, 5));
            acuario.agregarAnimal(new Crustaceo("Cangrejo", 2.0, 8));
            // Intento agregar otro animal con el mismo nombre "Nemo"
            acuario.agregarAnimal(new Crustaceo("Nemo", 2.0, 8));
        } catch (AnimalDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\nAnimales en el acuario:");
        acuario.mostrarAnimales();

        System.out.println("\nAcciones:");
        for (Animal a : acuario.getAnimales()) {
            if (a instanceof Nadador) {
                ((Nadador) a).nadar();
            }
            if (a instanceof BuscadorAlimento) {
                ((BuscadorAlimento) a).buscarAlimento();
            }
        }
    }
    
}
