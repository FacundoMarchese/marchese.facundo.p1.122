package parcialacuario122marchesefacundo;

import java.util.*;

public class Acuario {
    private List<Animal> animales;

    public Acuario() {
        animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal animal) throws AnimalDuplicadoException {
        for (Animal a : animales) {
            if (a.getNombre().equalsIgnoreCase(animal.getNombre())) {
                throw new AnimalDuplicadoException("Ya existe un animal con el nombre: " + animal.getNombre());
            }
        }
        animales.add(animal);
    }

    public void eliminarAnimal(String nombre) {
        animales.removeIf(a -> a.getNombre().equalsIgnoreCase(nombre));
    }

    public Animal buscarAnimal(String nombre) {
        for (Animal a : animales) {
            if (a.getNombre().equalsIgnoreCase(nombre)) {
                return a;
            }
        }
        return null;
    }

    public double getTotalPeso() {
        double total = 0;
        for (Animal a : animales) {
            total += a.getPeso();
        }
        return total;
    }

    public Animal getAnimalMasPesado() {
        return animales.stream().max(Comparator.comparingDouble(Animal::getPeso)).orElse(null);
    }

    public void mostrarAnimales() {
        for (Animal a : animales) {
            System.out.println(a);
        }
    }

    @Override
    public String toString() {
        return "Acuario con " + animales.size() + " animales.";
    }

    public List<Animal> getAnimales() {
    return animales;
}

}
