package parcialacuario122marchesefacundo;

public interface BuscadorAlimento {
    void buscarAlimento();
}
