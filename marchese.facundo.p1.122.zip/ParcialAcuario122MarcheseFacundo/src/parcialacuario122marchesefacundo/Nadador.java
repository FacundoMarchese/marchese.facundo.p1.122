package parcialacuario122marchesefacundo;

public interface Nadador {
    void nadar();
}
