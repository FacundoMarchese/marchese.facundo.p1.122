package parcialacuario122marchesefacundo;

public class MamiferoMarino extends Animal implements Nadador, BuscadorAlimento {
    private int frecuenciaRespiracion;

    public MamiferoMarino(String nombre, double peso, int frecuenciaRespiracion) {
        super(nombre, peso);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }

    public int getFrecuenciaRespiracion() { return frecuenciaRespiracion; }
    public void setFrecuenciaRespiracion(int frecuencia) { this.frecuenciaRespiracion = frecuencia; }

    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando.");
    }

    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " esta buscando alimento.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Frecuencia respiracion: " + frecuenciaRespiracion + " seg";
    }
    
}
