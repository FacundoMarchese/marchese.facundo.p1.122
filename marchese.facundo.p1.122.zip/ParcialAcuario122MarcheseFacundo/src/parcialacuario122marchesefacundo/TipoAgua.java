package parcialacuario122marchesefacundo;

public enum TipoAgua {
    DULCE, SALADA
}
