package parcialacuario122marchesefacundo;

public class Pez extends Animal implements Nadador {
    private TipoAgua tipoAgua;

    public Pez(String nombre, double peso, TipoAgua tipoAgua) {
        super(nombre, peso);
        this.tipoAgua = tipoAgua;
    }

    public TipoAgua getTipoAgua() { return tipoAgua; }
    public void setTipoAgua(TipoAgua tipoAgua) { this.tipoAgua = tipoAgua; }

    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Tipo de agua: " + tipoAgua;
    }
    
}
