package parcialacuario122marchesefacundo;

public class Crustaceo extends Animal implements BuscadorAlimento {
    private int numPatas;

    public Crustaceo(String nombre, double peso, int numPatas) {
        super(nombre, peso);
        this.numPatas = numPatas;
    }

    public int getNumPatas() { return numPatas; }

    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " esta buscando alimento.");
    }

    @Override
    public String toString() {
        return super.toString() + ", Numero de patas: " + numPatas;
    }
    
}
