package acuario122;

public class Crustaceo extends Animal implements BuscadorAlimento {
 
    private int numeroPatas;

    public Crustaceo(int numeroPatas, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        this.numeroPatas = numeroPatas;
    }

    public int getNumeroPatas() {
        return numeroPatas;
    }

    @Override
    public void buscarAlimento() {
        System.out.println("El Crustaceo "+ getNombre() + " esta buscando alimento!!");
    }
    
    @Override
    public String toString() {
        String sbBase = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(sbBase);
        sb.append(System.lineSeparator());
        sb.append("Numero de Patas: ").append(this.getNumeroPatas());
        sb.append(System.lineSeparator());
        return sb.toString();
    }
    
}
