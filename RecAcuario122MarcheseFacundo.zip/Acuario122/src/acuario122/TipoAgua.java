package acuario122;

public enum TipoAgua {
    DULCE,
    SALADA;
}
