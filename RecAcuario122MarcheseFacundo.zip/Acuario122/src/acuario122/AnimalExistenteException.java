package acuario122;

public class AnimalExistenteException extends RuntimeException {
    
    private static final String MESSAGE = "ERROR: El animal ingresado ya existe";

    public AnimalExistenteException() {
        this(MESSAGE);
    }
    
    public AnimalExistenteException(String message) {
        super(message);
    }
    
    
    
}
