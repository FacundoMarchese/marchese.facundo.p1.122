package acuario122;

public class Acuario122 {

    public static void main(String[] args) {
        
        Acuario acua1 = new Acuario("Hola Mundo Marino");
        
        try {
        acua1.agregarAnimal(new Pez(10, "Nemo", "Tropical", TipoAgua.DULCE));
        acua1.agregarAnimal(new Pez(15, "Lebiste", "Fria", TipoAgua.SALADA));
        
        //Repetido:
        acua1.agregarAnimal(new Pez(15, "Lebiste", "Fria", TipoAgua.SALADA));
        
        acua1.agregarAnimal(new MamiferoMarino(10, "Delfin", "Tropical", TipoAgua.SALADA));
        acua1.agregarAnimal(new MamiferoMarino(30, "Ballena Franca", "Fria", TipoAgua.SALADA));
        
        acua1.agregarAnimal(new Crustaceo(10, "Langosta", "Tropical", TipoAgua.DULCE));
        acua1.agregarAnimal(new Crustaceo(10, "Centolla", "Fria", TipoAgua.SALADA));
        
        }catch(AnimalExistenteException ex){
            System.out.println(ex.getMessage());
        }catch(NullPointerException ex2){
            System.out.println(ex2.getMessage());
        }
        
        System.out.println("MUESTRO ANIMALES!!");
        acua1.mostrarAnimales();
        
        System.out.println("\nNADANDO!!");
        acua1.nadar();
        System.out.println("\nBUSCANDO ALIMENTO!!");
        acua1.buscarAlimento();
        
        System.out.println("\nFILTRO TIPO AGUA!!");
        acua1.filtrarPorTipoAgua(TipoAgua.DULCE);
        //Retorno Lista
        System.out.println("\nFILTRO TIPO AGUA MOSTRANDO RETURN LISTA!!");
        System.out.println(acua1.filtrarPorTipoAgua(TipoAgua.SALADA));
        
        System.out.println("\nFILTRO ANIMALES!!");
        acua1.mostrarAnimalesPorTipo("Pez");
    }
    
}
