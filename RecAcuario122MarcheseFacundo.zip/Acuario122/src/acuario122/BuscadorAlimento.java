package acuario122;

public interface BuscadorAlimento {
    
    void buscarAlimento();
    
}
