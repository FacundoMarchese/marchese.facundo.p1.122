package recuperatoriocriaturas122marchesefacundo;

public interface Regenerable {
    void regenerarEnergia();
}
