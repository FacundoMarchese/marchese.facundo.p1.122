package recuperatoriocriaturas122marchesefacundo;

import java.util.*;
import java.util.stream.Collectors;

public class SistemaCriaturas {

    private final List<Criatura> criaturas;

    public SistemaCriaturas() {
        this.criaturas = new ArrayList<>();
    }

    public void agregarCriatura(Criatura criatura)
            throws CriaturaDuplicadaException, CriaturaInvalidaException {

        if (criatura == null)
            throw new CriaturaInvalidaException("No se puede agregar una criatura nula.");

        if (criaturas.contains(criatura)) {
            throw new CriaturaDuplicadaException(
                "Ya existe una criatura con el nombre '" + criatura.getNombre() +
                "' en la region '" + criatura.getRegion() + "'."
            );
        }

        criaturas.add(criatura);
    }

    public List<Criatura> getCriaturas() {
        return Collections.unmodifiableList(criaturas);
    }

    public List<Criatura> filtrarPorNivelDeMagia(NivelMagia nivel) {
        return criaturas.stream()
                .filter(c -> c.getNivelMagia() == nivel)
                .collect(Collectors.toList());
    }

    /** tipo puede ser: "Dragon", "Elfo", "Golem" (no sensible a mayúsculas) */
    public List<Criatura> filtrarPorTipoDeCriatura(String tipo) {

        String t = tipo.toLowerCase();

        return criaturas.stream()
                .filter(c ->
                        (t.equals("dragon") && c instanceof Dragon) ||
                        (t.equals("elfo")   && c instanceof Elfo)   ||
                        (t.equals("golem")  && c instanceof Golem)
                )
                .collect(Collectors.toList());
    }

    public void entrenarCriaturas() {
        for (Criatura c : criaturas) {
            if (c instanceof Entrenable e) {
                e.entrenar();
            } else {
                System.out.println(c.getNombre() + " no puede entrenar.");
            }
        }
    }

    public void regenerarEnergias() {
        for (Criatura c : criaturas) {
            if (c instanceof Regenerable r) {
                r.regenerarEnergia();
            } else {
                System.out.println(c.getNombre() + " no puede regenerar energia.");
            }
        }
    }
}
