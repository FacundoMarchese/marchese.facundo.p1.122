package recuperatoriocriaturas122marchesefacundo;

public class Golem extends Criatura implements Regenerable {

    private final int pesoToneladas;

    public Golem(String nombre, String region, NivelMagia nivel, int pesoToneladas)
            throws CriaturaInvalidaException {
        super(nombre, region, nivel);

        if (pesoToneladas < 1 || pesoToneladas > 20) {
            throw new CriaturaInvalidaException("El peso debe estar entre 1 y 20 toneladas.");
        }

        this.pesoToneladas = pesoToneladas;
    }

    public int getPesoToneladas() { return pesoToneladas; }

    @Override
    public void regenerarEnergia() {
        System.out.println(getNombre() + " absorbe energia de la tierra.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Peso: " + pesoToneladas + " toneladas";
    }
    
}
