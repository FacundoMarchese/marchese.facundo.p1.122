package recuperatoriocriaturas122marchesefacundo;

public class Elfo extends Criatura implements Entrenable, Regenerable {

    private final String habilidadEspecial;

    public Elfo(String nombre, String region, NivelMagia nivel, String habilidadEspecial)
            throws CriaturaInvalidaException {
        super(nombre, region, nivel);

        if (habilidadEspecial == null || habilidadEspecial.isBlank()) {
            throw new CriaturaInvalidaException("La habilidad especial no puede estar vacia.");
        }

        this.habilidadEspecial = habilidadEspecial;
    }

    public String getHabilidadEspecial() { return habilidadEspecial; }

    @Override
    public void entrenar() {
        System.out.println(getNombre() + " entrena su habilidad especial: " + habilidadEspecial);
    }

    @Override
    public void regenerarEnergia() {
        System.out.println(getNombre() + " regenera energía con magia elfica.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Habilidad: " + habilidadEspecial;
    }
    
}
