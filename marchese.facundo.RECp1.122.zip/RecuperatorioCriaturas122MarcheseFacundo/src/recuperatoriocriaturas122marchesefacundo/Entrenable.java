package recuperatoriocriaturas122marchesefacundo;

public interface Entrenable {
    void entrenar();
}
