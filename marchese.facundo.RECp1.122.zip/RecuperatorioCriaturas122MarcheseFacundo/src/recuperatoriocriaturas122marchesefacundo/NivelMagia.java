package recuperatoriocriaturas122marchesefacundo;

public enum NivelMagia {
    BAJO, MEDIO, ALTO
}

