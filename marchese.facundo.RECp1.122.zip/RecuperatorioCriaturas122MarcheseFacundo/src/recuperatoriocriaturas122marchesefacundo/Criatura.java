package recuperatoriocriaturas122marchesefacundo;

public abstract class Criatura {
        private final String nombre;
    private final String region;
    private final NivelMagia nivelMagia;

    protected Criatura(String nombre, String region, NivelMagia nivelMagia)
            throws CriaturaInvalidaException {

        if (nombre == null || nombre.isBlank()) {
            throw new CriaturaInvalidaException("El nombre no puede estar vacio.");
        }
        if (region == null || region.isBlank()) {
            throw new CriaturaInvalidaException("La región no puede estar vacia.");
        }
        if (nivelMagia == null) {
            throw new CriaturaInvalidaException("El nivel de magia no puede ser nulo.");
        }

        this.nombre = nombre;
        this.region = region;
        this.nivelMagia = nivelMagia;
    }

    public String getNombre() { return nombre; }
    public String getRegion() { return region; }
    public NivelMagia getNivelMagia() { return nivelMagia; }

    @Override
    public String toString() {
        return "Nombre: " + nombre +
               " | Región: " + region +
               " | Nivel Magia: " + nivelMagia;
    }

    @Override
    public int hashCode() {
        return (nombre + region).toLowerCase().hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Criatura)) return false;
        Criatura c = (Criatura) o;
        return nombre.equalsIgnoreCase(c.nombre) &&
               region.equalsIgnoreCase(c.region);
    }
}
