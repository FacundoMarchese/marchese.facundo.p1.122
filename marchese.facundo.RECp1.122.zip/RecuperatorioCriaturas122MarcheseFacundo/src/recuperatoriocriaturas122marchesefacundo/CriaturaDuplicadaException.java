package recuperatoriocriaturas122marchesefacundo;

public class CriaturaDuplicadaException extends Exception {

    public CriaturaDuplicadaException(String msg) {
        super(msg);
    }
}
