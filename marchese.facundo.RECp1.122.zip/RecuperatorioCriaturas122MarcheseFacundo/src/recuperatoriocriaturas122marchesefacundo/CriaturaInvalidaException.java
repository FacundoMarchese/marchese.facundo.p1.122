package recuperatoriocriaturas122marchesefacundo;

public class CriaturaInvalidaException extends Exception {

    public CriaturaInvalidaException(String msg) {
        super(msg);
    }
}
