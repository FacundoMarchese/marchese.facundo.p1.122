package recuperatoriocriaturas122marchesefacundo;

public class AccionNoSoportadaException extends Exception {

    public AccionNoSoportadaException(String msg) {
        super(msg);
    }
}
