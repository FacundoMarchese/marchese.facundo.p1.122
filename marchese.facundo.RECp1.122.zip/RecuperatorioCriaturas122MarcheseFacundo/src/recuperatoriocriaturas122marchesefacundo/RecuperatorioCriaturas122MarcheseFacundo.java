package recuperatoriocriaturas122marchesefacundo;

public class RecuperatorioCriaturas122MarcheseFacundo {


    public static void main(String[] args) {
        SistemaCriaturas sistema = new SistemaCriaturas();

        try {
            sistema.agregarCriatura(new Dragon("Fafnir", "Montanias", NivelMagia.ALTO, 300));
            sistema.agregarCriatura(new Elfo("Lyrien", "Bosques", NivelMagia.MEDIO, "Telepatia"));
            sistema.agregarCriatura(new Golem("Rok", "Caniones", NivelMagia.BAJO, 12));

            System.out.println("\n--- TODAS LAS CRIATURAS ---");
            sistema.getCriaturas().forEach(System.out::println);

            System.out.println("\n--- ENTRENAMIENTO ---");
            sistema.entrenarCriaturas();

            System.out.println("\n--- REGENERACION ---");
            sistema.regenerarEnergias();

            System.out.println("\n--- MAGIA ALTA ---");
            sistema.filtrarPorNivelDeMagia(NivelMagia.ALTO)
                    .forEach(System.out::println);

            System.out.println("\n--- SOLO ELFOS ---");
            sistema.filtrarPorTipoDeCriatura("Elfo")
                    .forEach(System.out::println);

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
        }
    }
    
}
