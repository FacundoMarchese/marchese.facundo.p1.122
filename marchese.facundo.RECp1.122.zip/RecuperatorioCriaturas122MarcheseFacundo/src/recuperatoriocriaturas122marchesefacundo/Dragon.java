package recuperatoriocriaturas122marchesefacundo;

public class Dragon extends Criatura implements Entrenable {

    private final int potenciaFuego;

    public Dragon(String nombre, String region, NivelMagia nivel, int potenciaFuego)
            throws CriaturaInvalidaException {
        super(nombre, region, nivel);

        if (potenciaFuego <= 0) {
            throw new CriaturaInvalidaException("La potencia de fuego debe ser mayor a 0.");
        }

        this.potenciaFuego = potenciaFuego;
    }

    public int getPotenciaFuego() { return potenciaFuego; }

    @Override
    public void entrenar() {
        System.out.println(getNombre() + " aumenta su potencia de fuego.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Potencia de fuego: " + potenciaFuego;
    }
    
}
